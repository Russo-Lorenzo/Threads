
public class Buffer {
	private int num;
	private boolean available = false;
	
	public synchronized void putValue(int n) {
		while(available) {											// Controllo se il buffer è occupato
			try {
				wait();												// Se è occupato mando in wait per aspettare che venga preso il valore
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		this.num = n;												// Quando è libero inserisco il numero generato dal produttore
		available = !available;										// Imposto il buffer su occupato
		notify();													// "Sveglio" il thread consumatore
	}
	
	public synchronized int getValue() {
		while (!available) {										// Controllo se c'è un valore nel buffer
            try {
                wait();  											// Se non c'è aspetto
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
		
		available = !available;										// Imposto il buffero su libero
		notify();													// Risveglio il produttore
		return num;													// Do il numero al consumatore
	}
}
