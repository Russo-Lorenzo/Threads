import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num, tempo = 100, in;											// Dichiaro una variabile per il numero di persone, una per le volte che controllerò quanta gente
		Scanner cin = new Scanner(System.in);								// c'è dentro e una per tenere il conto delle persona all'interno
		
		System.out.println("Quante persone entrano in discoteca? ");
		num = cin.nextInt();
				
		Persona[] p = new Persona[num];
		
		for(int i = 0; i < p.length; i++) {
			p[i] = new Persona();
		}
		
		for(int i = 0; i < p.length; i++) {
			p[i].start();
		}
		
		for(int i = 0; i < tempo; i++) {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			in = 0;															// Inizializzo la variabile del conta a 0
			
			for(int j = 0; j < p.length; j++) {								
				if(p[j].In_or_not() == true) {								// Controllo se il valore booleano che indica se la persona è 
																			// dentro o fuori della classe persona è vero o falso
					in++;													// Se è vero incremento la mia variabile che conta
				}
			}
			
			System.out.println("In discoteca ci sono " + in + " persone\n");
		}
	}

}
