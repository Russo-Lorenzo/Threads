import java.util.Random;

public class Gruppi extends Thread implements Runnable{

	Random random = new Random();
	private int in_out_time, time = 1000, n_gruppo;								// Dichiaro una variabile che memorizza il tempo che la persona starà fuori o dentro
																		// e una per le volte che entrerà e uscirà
	private boolean in_or_out;											// Dichiaro anche una variabile che mi servirà per controllare se è fuori o dentro la persona
	
	
	public Gruppi() {
		n_gruppo = random.nextInt(15);
		in_out_time = random.nextInt(10000);							// Inizializzo la mia variabile con un numero random dai 0 ai 10000 ms (0 a 10 s)
		in_or_out = true;												// Faccio entrare la persona
	}
	
	public boolean In_or_not() {
		return in_or_out;
	}
	
	public int Persone_gruppo() {
		return n_gruppo;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		for(int i = 0; i < time; i++){
			try {
				sleep(in_out_time);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			in_or_out =! in_or_out;										// La persona se è all'interno esce se è fuori entra
		}
	}

}