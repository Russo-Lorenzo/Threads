import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		int t, n;
		long d;
		Scanner cin = new Scanner(System.in);			
		
		System.out.println("Quanti thread vuoi creare?\n -> ");
		t = cin.nextInt();
		
		System.out.println("Qual'è il valore massimo a cui contare?\n -> ");
		n = cin.nextInt();
		
		System.out.println("Quanti millisecondi vuoi far aspettare\n -> ");
		d = cin.nextInt();
		
		Thread[] contatori = new Thread[t];										// Creo un vettore di t trhead
			
		for (int i = 0; i < contatori.length; i++) {
			
			Contatore c = new Contatore(n, i);									// Creo un contatore e gli passo le variabili per il numero fino a cui contare e la variabile che utilizzerò per l'id
			contatori[i] = new Thread(c);										// Passo al thread il contatore
		}
		
		for (int i = 0; i < contatori.length; i++) {
			try {
	            																// Fa aspettare il thread corrente
	            contatori[i].sleep(d);
	        } catch (InterruptedException e) {
	            																// Gestisce l'eccezione se il thread viene interrotto durante l'attesa
	            System.out.println("Il thread è stato interrotto");
	        }
			
			contatori[i].start();
			
		}
	}
}
