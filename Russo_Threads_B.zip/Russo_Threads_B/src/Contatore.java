
public class Contatore implements Runnable{
	
	private int limit, conta, id;											// Creo le variabili per il valore massimo, il contatore e per segnarmi una specie di identificatore del thread
	private boolean odd;													// Creo il booleano che utilizzerò per decidere quali thread faranno la conta crescente e quali quella decrescente

	
	public Contatore(int n, int i) {										
		this.limit = n;														
		this.id = i;
		this.odd = (i % 2 == 0);
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		System.out.println("Inizio a contare\n");
		
		if (odd == true) {													// I thread con "id" pari inizieranno la conta da 0
			
			conta = 0;
			
			for (int i = 0; i < limit; i++) {
			
				conta ++;
				System.out.print("Threads n°"+ id +" " + conta + "\n");
				
			}
		}else {
			
			conta = limit + 1;												// I trhead con "id" dispari inizieranno da 10, conta sarà limit + 1 perche viene decrementato prima del primo print
			
			for (int i = 0; i < limit; i++) {
				
				conta --;
				System.out.print("Threads n°"+ id +" " + conta + "\n");
			}
		}
		
		System.out.println("Finito di contare\n");
	}
}
