
public class Contatore extends Thread implements Runnable {

	int num_max, conta = 0;
	
	public Contatore(int n) {
		this.num_max = n;
	}	
		
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		for(int i = 1; i <= num_max; i++) {
			try {
				sleep(120);							
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
						
			conta++;
		}
		
		
	}

}
