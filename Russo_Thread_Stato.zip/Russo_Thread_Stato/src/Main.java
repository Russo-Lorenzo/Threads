import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int t, n;
		Scanner cin = new Scanner(System.in);
		
		System.out.println("Quanti thread vuoi creare: ");
		t = cin.nextInt();
		
		System.out.println("Inserisci il possibile numero massimo: ");
		n = cin.nextInt();
		
		Principale p = new Principale(t,n);
		p.start();
				
	}

}
