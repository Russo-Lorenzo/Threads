import java.util.Random;

public class Principale extends Thread implements Runnable{

	int num_t, num_max, done;
	Random random = new Random();
	
	
	public Principale(int t, int n) {
		this.num_t = t;
		this.num_max = n;		
	}
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		Contatore[] contatori = new Contatore[num_t];			// Creo un vettore di Thread della classe Contatore della lunghezza che sceglie l'utente
		
		for(int i = 0; i < contatori.length; i++) {
			
			int random_n = random.nextInt(num_max + 1);			// Randomizzo un numero tra 1 e il numero dell'utente
			contatori[i] = new Contatore(random_n);				// Inizializzo il contatore con il numero che esce dal random
	
		}
		
		for(int i = 0; i < contatori.length; i++) {
			contatori[i].start();	
		}
		
		do {
			
			try {
				sleep(1000);									// Faccio aspettare al thread un secondo prima di effettuare il controllo	
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			done = 0;											// Imposto la mia variabile done a 0 così che il do finisca solo quando tutti i thread sono finit 
			
			for(int i = 0; i < contatori.length; i++) {
				
				if(contatori[i].isAlive() == true) {			// Controllo se il contatore ha finito di contare 
					
					System.out.println("Thread " + i + ": è arrivato a " + contatori[i].conta);

				}else {
					System.out.println("Thread " + i + ": Completato");
					done++;										// Se ha finito incremento done per verificare poi se hanno finito tutti
				}
				
			}
			
			System.out.println("\n\n");
		}while(done != num_t);									// Se done è uguale al numero dei thread significa che tutti i thread sono terminati
		
		System.out.println("\nTutti i thread sono completati");
		
	}

}
